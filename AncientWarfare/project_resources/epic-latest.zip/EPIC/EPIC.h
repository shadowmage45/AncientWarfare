#pragma once

#include "resource.h"


double GetRealTime();
void InitRealTime();

